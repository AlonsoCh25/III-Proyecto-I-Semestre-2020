# III-Proyecto-I-Semestre-2020
3C: Company System With Face Recognition To Log
